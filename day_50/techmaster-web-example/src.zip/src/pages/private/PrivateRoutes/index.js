import React from 'react'

function PrivateRoutes() {
    return (
        <div>PrivateRoutes</div>
    )
}

export default PrivateRoutes