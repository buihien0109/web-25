// Danh sách tư vấn viên
export const users = [
    {
        id: 1,
        name: "Phạm Thị Mẫn",
        email: "man@gmail.com",
        phone: "0988888888",
        avatar: "https://media.techmaster.vn/api/static/crop/bv9jp4k51co7nj2mhht0",
        password: "111"
    },
    {
        id: 2,
        name: "Nguyễn Đức Thịnh",
        email: "thinh@gmail.com",
        phone: "0977777777",
        avatar: "https://media.techmaster.vn/api/static/c2m5ou451cob24f6skeg/ccjlg0NC",
        password: "111"
    },
    {
        id: 3,
        name: "Nguyễn Thanh Hương",
        email: "huong@gmail.com",
        phone: "0966666666",
        avatar: "https://media.techmaster.vn/api/static/crop/brm3huc51co50mv77sag",
        password: "111"
    }
]