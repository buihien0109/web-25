import Home from "./pages/Home";
import Header from "./components/Header";
import Footer from "./components/Footer";
import Course from "./pages/Course";

function App() {
  return (
    <>
      <Header />
      <Course />
      <Footer />
    </>
  );
}

export default App;
