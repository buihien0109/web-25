import React from 'react'

function Header() {
    return (
        <div className="header">
            <nav className="navbar navbar-expand-lg navbar-dark">
                <div className="container-fluid">
                    <a className="navbar-brand" href="/">
                        <img src="https://techmaster.vn/resources/image/logo-techmaster/white/white_200x74.png"
                            alt="logo-techmaster" />
                    </a>

                    <button className="navbar-toggler" type="button" data-bs-toggle="offcanvas"
                        data-bs-target="#offcanvasExample" aria-controls="offcanvasExample" aria-expanded="false"
                        aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>

                    <div className="collapse navbar-collapse justify-content-end" id="navbarNav">
                        <ul className="navbar-nav">
                            <li className="nav-item">
                                <a className="nav-link text-white" href="/lo-trinh">LỘ TRÌNH</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link text-white" href="/khoa-hoc">KHÓA HỌC</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link text-white" href="/san-pham-hoc-vien">SẢN PHẨM HỌC VIÊN</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link text-white" href="/bai-viet">BLOG</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link text-white" href="/trung-tam">VỀ CHÚNG TÔI</a>
                            </li>
                        </ul>

                        <div className="d-flex align-items-center ms-5">
                            <div className="cart">
                                <a href="/gio-hang" className="text-white position-relative">
                                    <span className="fs-5"><i className="fa-solid fa-cart-shopping"></i></span>
                                    <span className="cart-count bg-info px-1 rounded-2 position-absolute">0</span>
                                </a>
                            </div>
                            <div className="user ms-4">
                                <button type="button" className="bg-transparent border-0 text-white" data-bs-toggle="modal"
                                    data-bs-target="#modal-login">
                                    <span className="fs-5"><i className="fa-solid fa-user"></i></span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
        </div>
    )
}

export default Header