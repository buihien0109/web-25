import "./ShoppingCart.css";

function ShoppingCart() {
    return (
        <>
            <section className='py-5'>
            <div className='container'>
                <h1 className='text-center fs-4 mb-5'>ShoppingCart Page</h1>
            </div>
        </section>
        </>
    )
}

export default ShoppingCart