import React from 'react'
import CourseItem from '../CourseItem'

function CourseList() {
    return (
        <div className="course-list row">
            <CourseItem />
        </div>
    )
}

export default CourseList