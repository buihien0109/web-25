import React from 'react'
import ProductItem from '../ProductItem'

function ProductList() {
    return (
        <div className="col-md-8">
            <div className="product-list">
                <ProductItem />
                <ProductItem />
                <ProductItem />
            </div>
        </div>
    )
}

export default ProductList